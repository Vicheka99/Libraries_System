export default function Popular() {
  return (
    <main className="g-main">
      <h1>Popular</h1>
    </main>
  );
}
