export default function Home() {
  return (
    <main className="g-main">
      <div className="g-main-box">{/* your home content goes here */}</div>
    </main>
  );
}
