export default function BookDetail() {
  return (
    <main className="g-main">
      <h1>Book Detail</h1>
    </main>
  );
}
